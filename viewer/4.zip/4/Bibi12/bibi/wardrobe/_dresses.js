module.exports = {
    'custom-made': [
        'everyday'
    ],
    'ready-made': [
    ]
};
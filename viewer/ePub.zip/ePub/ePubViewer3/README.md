# ePubViewer

## About
A web-based ebook viewer.

<a href="https://pgaskin.net/ePubViewer">Try it out now.</a>

## Features
- Modern, responsive UI
- Themes, fonts, line spacing, margins, font size settings
- Search
- About view
- Go to page
- Location numbers
- More

## Compatibility

Tested with Edge 17+, Mozilla Firefox 50+, Google Chrome 50+, Safari 10+, and Opera 40+. Does not work on Internet Explorer.

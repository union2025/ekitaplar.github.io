# ePubViewer

## About
A web-based ebook viewer.

<a href="http://geek1011.github.io/ePubViewer">Try out the web-app now</a>

## Compatibility

Tested with Mozilla Firefox 20+, Google Chrome 30+, and Opera 30+.
